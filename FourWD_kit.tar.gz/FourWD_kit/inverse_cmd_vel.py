#!/usr/bin/env python
import rospy
import tf.transformations
from geometry_msgs.msg import Twist


rospy.init_node('cmd_vel_listener')

pub_cmd = rospy.Publisher("/cmd_vel_inverse", Twist, queue_size=1)



def callback(msg):
    rospy.loginfo("Received a /cmd_vel_inverse message!")
    corrected_msg = Twist()
    corrected_msg = msg
    corrected_msg.angular.z = -1*msg.angular.z
    corrected_msg.linear.x = -1*msg.linear.x
    pub_cmd.publish(corrected_msg)
    rospy.loginfo("Published corrected /cmd_vel msg!")
    
rospy.Subscriber("/cmd_vel", Twist, callback)
rospy.spin()
